﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using WebApplication2.Models;

namespace WebApplication2.Models
{
    public class ApplicationDbInitializer : CreateDatabaseIfNotExists<ApplicationDbContext>//DropCreateDatabaseAlways
    {

        //private ApplicationDbContext db = new ApplicationDbContext();
        protected override void Seed(ApplicationDbContext context)
        {
            addInitialAdmin(context);
            addInitialUsers(context);
            addInitialPatients(context);
            addInitialOrganization(context);
            addInitialDoctors(context);
            addInitialTests(context);
            addInitialMedications(context);
            addInitialInvoices(context);
            addInitialPatientMedications(context);
            addInitialPatientTests(context);
            base.Seed(context);

        }


        private void addInitialMedications(ApplicationDbContext context)
        {
            if (context.Medications.Count() == 0)
            {/*
                Medication medication1 = new Medication();
                medication1.Name = "SSRI";
                medication1.Description = "Selective serotonin reuptake inhibitors";
                medication1.Price = 50;
                context.Medications.Add(medication1);

                Medication medication2 = new Medication();
                medication2.Name = "TCA";
                medication2.Description = "Tricyclic antidepressants ";
                medication2.Price = 60;
                context.Medications.Add(medication2);
                */
                context.Medications.Add(new Medication() { Name = "Lipitor", Description = "a cholesterol-lowering statin drug ",Price = 50 });
                context.Medications.Add(new Medication() { Name = "Nexium", Description = "an antacid drug", Price = 50 });
                context.Medications.Add(new Medication() { Name = "Plavix", Description = "a blood thinner", Price = 50 });
                context.Medications.Add(new Medication() { Name = "Advair Diskus", Description = "an asthma inhaler", Price = 50 });
                context.Medications.Add(new Medication() { Name = "Abilify ", Description = "an antipsychotic drug", Price = 50 });
                context.Medications.Add(new Medication() { Name = "Seroquel ", Description = "an antipsychotic drug ", Price = 50 });
                context.Medications.Add(new Medication() { Name = "Singulair ", Description = "an oral asthma drug", Price = 50 });
                context.Medications.Add(new Medication() { Name = "Crestor ", Description = "a cholesterol-lowering statin drug", Price = 50 });
                context.Medications.Add(new Medication() { Name = "Actos ", Description = "a diabetes drug", Price = 50 });
                context.Medications.Add(new Medication() { Name = "Epogen ", Description = "an injectable anemia drug", Price = 50 });
                context.SaveChanges();
            }
        }
        private void addInitialInvoices(ApplicationDbContext context)
        {
            if (context.Invoices.Count() == 0)
            {

                Patient p1 = (from p in context.Patients where p.id == 1 select p).FirstOrDefault();
                Patient p2 = (from p in context.Patients where p.id == 2 select p).FirstOrDefault();

                Invoice invoice1 = new Invoice();
                invoice1.InvoiceDate = DateTime.Now;
                invoice1.Status = "Pending";
                invoice1.Patient = p1;
                context.Invoices.Add(invoice1);

                Invoice invoice2 = new Invoice();
                invoice2.InvoiceDate = DateTime.Now;
                invoice2.Status = "Pending";
                invoice2.Patient = p2;
                context.Invoices.Add(invoice2);

                Invoice invoice3 = new Invoice();
                invoice3.InvoiceDate = DateTime.Now;
                invoice3.Status = "Pending";
                invoice3.Patient = p1;
                context.Invoices.Add(invoice3);

                Invoice invoice4 = new Invoice();
                invoice4.InvoiceDate = DateTime.Now;
                invoice4.Status = "Pending";
                invoice4.Patient = p2;
                context.Invoices.Add(invoice4);

                context.SaveChanges();
            }
        }
        private void addInitialTests(ApplicationDbContext context)
        {
            if (context.Tests.Count() == 0)
            {
                /*
                Test test1 = new Test();
                test1.Code = "FBC";
                test1.Description = "Full Blood Count";
                test1.Price = 50;
                context.Tests.Add(test1);

                Test test2 = new Test();
                test2.Code = "AFP";
                test2.Description = "Alpha-fetoprotein Blood Test";
                test2.Price = 60;
                context.Tests.Add(test2);
                */

                context.Tests.Add(new Test() { Code = "Blood", Description = "Full Blood Count", Price = 50 });
                context.Tests.Add(new Test() { Code = "Urine", Description = "Urine flow rate", Price = 50 });
                context.Tests.Add(new Test() { Code = "Cerebrospinal Fluid", Description = "Fluid that surrounds the spinal cord and brain", Price = 50 });
                context.Tests.Add(new Test() { Code = "Synovial Fluid", Description = "Fluid within a joint", Price = 50 });
                context.SaveChanges();
            }
        }
        private void addInitialDoctors(ApplicationDbContext context)
        {
            if (context.Doctors.Count() == 0)
            {/*
                Doctor doctor1 = new Doctor();
                doctor1.Name = "Keeth Heres";
                doctor1.Email = "doctor1@healthcare.com";
                context.Doctors.Add(doctor1);

                Doctor doctor2 = new Doctor();
                doctor2.Name = "Hector Ramraz";
                doctor2.Email = "doctor2@healthcare.com";
                context.Doctors.Add(doctor2);
                */

                context.Doctors.Add(new Doctor() { Name = "Aamod Rao" });
                context.Doctors.Add(new Doctor() { Name = "david role" });
                context.Doctors.Add(new Doctor() { Name = "Ramneek Mahajan" });
                context.Doctors.Add(new Doctor() { Name = "Prashant Gedam" });
                context.SaveChanges();
            }
        }
        private void addInitialOrganization(ApplicationDbContext context)
        {
            if (context.Organizations.Count() == 0)
            {
                Organization organization = new Organization();
                organization.Name = "Health care services";
                organization.Address = "19th, Miller Street";
                organization.City = "Cumberland - 21502";
                organization.Email = "info@healthcare.com";
                organization.Phone = "1264856875";
                organization.TagLine = "It is an extensive network of state-of-the-art facilities staffed with skilled, carring professionals who are dedicated to the health and wellness of the communuties they serve.";
                context.Organizations.Add(organization);
                context.SaveChanges();
            }
        }
        private void addInitialPatients(ApplicationDbContext context)
        {
            if (context.Patients.Count() == 0)
            {
                Patient patient1 = new Patient();
                patient1.FirstName = "John";
                patient1.LastName = "Doe";
                patient1.Address = "467, ";
                patient1.Gender = "Male";
                patient1.Age = 25;
                patient1.Email = "user1@healthcare.com";
                patient1.PhoneNumber = "1264856875";
                context.Patients.Add(patient1);

                Patient patient2 = new Patient();
                patient2.FirstName = "Harry";
                patient2.LastName = "Potter";
                patient2.Address = "479, ";
                patient2.Gender = "Male";
                patient2.Age = 28;
                patient2.Email = "user2@healthcare.com";
                patient2.PhoneNumber = "2156468466";
                context.Patients.Add(patient2);

                context.SaveChanges();

                var UserManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(context));
                ApplicationUser user1 = UserManager.FindByName("User1");
                ApplicationUser user2 = UserManager.FindByName("User2");
                //context.Patients.First().User = user1;
                //context.Patients.().User = user2;
                (from p in context.Patients where p.id == 1 select p).FirstOrDefault().User = user1;
                (from p in context.Patients where p.id == 2 select p).FirstOrDefault().User = user2;

                //var result = (from p in context.Patients where p.FirstName == "John" select p).FirstOrDefault();
                //result.User = user;
                context.SaveChanges();
            }
        }
        private void addInitialPatientMedications(ApplicationDbContext context)
        {
            if (context.PatientMedications.Count() == 0)
            {
                Patient p1 = (from p in context.Patients where p.id == 1 select p).FirstOrDefault();
                Patient p2 = (from p in context.Patients where p.id == 2 select p).FirstOrDefault();
                Medication m1 = (from m in context.Medications where m.id == 1 select m).FirstOrDefault();
                Medication m2 = (from m in context.Medications where m.id == 2 select m).FirstOrDefault();
                Invoice i1 = (from i in context.Invoices where i.id == 1 select i).FirstOrDefault();
                Invoice i2 = (from i in context.Invoices where i.id == 2 select i).FirstOrDefault();

                PatientMedication pm1 = new PatientMedication();
                pm1.Patient = p1;
                pm1.Medication = m1;
                pm1.Price = m1.Price;
                pm1.Invoice = i1;
                pm1.StartDate = DateTime.Now;

                PatientMedication pm2 = new PatientMedication();
                pm2.Patient = p2;
                pm2.Medication = m2;
                pm2.Price = m2.Price;
                pm2.Invoice = i2;
                pm2.StartDate = DateTime.Now;

                context.PatientMedications.Add(pm1);
                context.PatientMedications.Add(pm2);

                context.SaveChanges();
            }
        }
        private void addInitialPatientTests(ApplicationDbContext context)
        {
            if (context.PatientTests.Count() == 0)
            {
                Patient p1 = (from p in context.Patients where p.id == 1 select p).FirstOrDefault();
                Patient p2 = (from p in context.Patients where p.id == 2 select p).FirstOrDefault();
                Test t1 = (from t in context.Tests where t.id == 1 select t).FirstOrDefault();
                Test t2 = (from t in context.Tests where t.id == 2 select t).FirstOrDefault();
                Test t3 = (from t in context.Tests where t.id == 3 select t).FirstOrDefault();
                Test t4 = (from t in context.Tests where t.id == 4 select t).FirstOrDefault();
                Doctor d1 = (from d in context.Doctors where d.id == 1 select d).FirstOrDefault();
                Doctor d2 = (from d in context.Doctors where d.id == 2 select d).FirstOrDefault();
                Doctor d3 = (from d in context.Doctors where d.id == 3 select d).FirstOrDefault();
                Doctor d4 = (from d in context.Doctors where d.id == 4 select d).FirstOrDefault();
                Invoice i1 = (from i in context.Invoices where i.id == 1 select i).FirstOrDefault();
                Invoice i2 = (from i in context.Invoices where i.id == 2 select i).FirstOrDefault();
                Invoice i3 = (from i in context.Invoices where i.id == 3 select i).FirstOrDefault();
                Invoice i4 = (from i in context.Invoices where i.id == 4 select i).FirstOrDefault();

                PatientTest pt1 = new PatientTest();
                pt1.Patient = p1;
                pt1.Test = t1;
                pt1.Price = t1.Price;
                pt1.Doctor = d1;
                pt1.Result = "Normal";
                pt1.Invoice = i1;
                pt1.TestDate = DateTime.Now;
                context.PatientTests.Add(pt1);

                PatientTest pt2 = new PatientTest();
                pt2.Patient = p2;
                pt2.Test = t2;
                pt2.Price = t2.Price;
                pt2.Doctor = d2;
                pt2.Result = "Normal";
                pt2.Invoice = i2;
                pt2.TestDate = DateTime.Now;
                context.PatientTests.Add(pt2);

                PatientTest pt3 = new PatientTest();
                pt3.Patient = p1;
                pt3.Test = t3;
                pt3.Price = t3.Price;
                pt3.Doctor = d3;
                pt3.Result = "Normal";
                pt3.Invoice = i3;
                pt3.TestDate = DateTime.Now;
                context.PatientTests.Add(pt3);


                PatientTest pt4 = new PatientTest();
                pt4.Patient = p1;
                pt4.Test = t4;
                pt4.Price = t4.Price;
                pt4.Doctor = d4;
                pt4.Result = "Normal";
                pt4.Invoice = i3;
                pt4.TestDate = DateTime.Now;
                context.PatientTests.Add(pt4);


                PatientTest pt5 = new PatientTest();
                pt5.Patient = p2;
                pt5.Test = t1;
                pt5.Price = t1.Price;
                pt5.Doctor = d4;
                pt5.Result = "Normal";
                pt5.Invoice = i4;
                pt5.TestDate = DateTime.Now;
                context.PatientTests.Add(pt5);

                context.SaveChanges();
            }
        }

        private void addInitialAdmin(ApplicationDbContext context)
        {

            var UserManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(context));
            var RoleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(context));

            string name = "Admin";
            string password = "Abc@123";

            //Create Role Admin if it does not exist	
            if (!RoleManager.RoleExists(name))
            {
                var roleresult = RoleManager.Create(new IdentityRole(name));
            }

            //Create User=Admin with password=123456	
            var user = new ApplicationUser();
            user.UserName = name;
            user.Email = "admin@health.com";
            var adminresult = UserManager.Create(user, password);

            //Add User Admin to Role Admin
            if (adminresult.Succeeded)
            {
                var result = UserManager.AddToRole(user.Id, name);
            }
        }
        private void addInitialUsers(ApplicationDbContext context)
        {

            var UserManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(context));
            var RoleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(context));

            string roleName = "User";
            string password = "Abc@123";

            //Create Role Admin if it does not exist	
            if (!RoleManager.RoleExists(roleName))
            {
                var roleresult = RoleManager.Create(new IdentityRole(roleName));
            }

            //Create User=Admin with password=123456	
            var user1 = new ApplicationUser();
            user1.UserName = "User1";
            user1.Email = "user1@health.com";
            var result1 = UserManager.Create(user1, password);

            //Add User Admin to Role Admin
            if (result1.Succeeded)
            {
                var result = UserManager.AddToRole(user1.Id, roleName);
            }
            //Create User=Admin with password=123456	
            var user2 = new ApplicationUser();
            user2.UserName = "User2";
            user2.Email = "user2@health.com";
            var result2 = UserManager.Create(user2, password);

            //Add User Admin to Role Admin
            if (result2.Succeeded)
            {
                var result = UserManager.AddToRole(user2.Id, roleName);
            }
        }
    }
}