﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;


namespace WebApplication2.Models
{
    public class PatientTest 
    {
        public int id { get; set; }

        [Display(Name = "Test Date")]
        public DateTime TestDate { get; set; }
        [Display(Name = "Result")]
        public string Result { get; set; }
        [Display(Name = "Price")]
        public double Price { get; set; }

        public virtual Invoice Invoice { get; set; }
        public virtual Doctor Doctor { get; set; }
        public virtual Patient Patient { get; set; }
        public virtual Test Test { get; set; }


    }
}