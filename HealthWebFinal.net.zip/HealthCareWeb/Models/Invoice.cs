﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;


namespace WebApplication2.Models
{
    public class Invoice 
    {
        public int id { get; set; }

        [Display(Name = "Invoice Date")]
        public DateTime? InvoiceDate { get; set; }
        [Display(Name = "Amount")]
        public double Amount { get{
                double a = PatientMedications == null ? 0 : PatientMedications.Sum(x => x.Price);
                double b = PatientTests ==null?0: PatientTests.Sum(x => x.Price);
                return a + b; 
            } }
        [Display(Name = "Status")]
        public string Status { get; set; }
        public virtual Patient Patient { get; set; }
        public virtual ICollection<PatientMedication> PatientMedications { get; set; }
        public virtual ICollection<PatientTest> PatientTests { get; set; }

    }
}