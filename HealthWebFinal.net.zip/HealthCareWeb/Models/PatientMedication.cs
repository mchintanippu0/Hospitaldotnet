﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;


namespace WebApplication2.Models
{
    public class PatientMedication 
    {
        public int id { get; set; }

        [Display(Name = "Price")]
        public double Price { get; set; }
        [Display(Name = "Start Date")]
        public DateTime StartDate { get; set; }

        public virtual Patient Patient { get; set; }
        public virtual Medication Medication { get; set; }
        public virtual Invoice Invoice { get; set; }


    }
}