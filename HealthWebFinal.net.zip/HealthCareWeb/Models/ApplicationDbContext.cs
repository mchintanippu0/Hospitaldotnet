﻿using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace WebApplication2.Models
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext()
            : base("DefaultConnection", throwIfV1Schema: false)
        {
        }

        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Patient>()
                .HasOptional<ApplicationUser>(p => p.User)
                .WithOptionalDependent(u => u.Patient).Map(p => p.MapKey("User_id"));
            /*
            modelBuilder.Entity<Schedule>()
    .HasRequired(r => r.Doctor)
    .WithMany(s => s.Schedules)
    .HasForeignKey(f => f.DoctorId)
    .WillCascadeOnDelete(false);
            modelBuilder.Entity<Schedule>()
   .HasRequired(r => r.Patient)
   .WithMany(s => s.Schedules)
   .HasForeignKey(f => f.PatientId)
   .WillCascadeOnDelete(false);
   */
            base.OnModelCreating(modelBuilder);
        }
        /*
         */

        public System.Data.Entity.DbSet<WebApplication2.Models.Test> Tests { get; set; }

        public System.Data.Entity.DbSet<WebApplication2.Models.Doctor> Doctors { get; set; }

        public System.Data.Entity.DbSet<WebApplication2.Models.Invoice> Invoices { get; set; }

        public System.Data.Entity.DbSet<WebApplication2.Models.Medication> Medications { get; set; }

        public System.Data.Entity.DbSet<WebApplication2.Models.Organization> Organizations { get; set; }

        public System.Data.Entity.DbSet<WebApplication2.Models.Patient> Patients { get; set; }

        public System.Data.Entity.DbSet<WebApplication2.Models.PatientMedication> PatientMedications { get; set; }

        public System.Data.Entity.DbSet<WebApplication2.Models.PatientTest> PatientTests { get; set; }

        public System.Data.Entity.DbSet<WebApplication2.Models.Schedule> Schedules { get; set; }
    }
}