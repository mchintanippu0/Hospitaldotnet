﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;


namespace WebApplication2.Models
{
    public class Schedule 
    {
        public int id { get; set; }

        [Display(Name = "Schedule Time")]
        public DateTime ScheduleTime { get; set; }

        [Display(Name = "Status")]
        public string Status { get; set; }
        
        public virtual Doctor Doctor { get; set; }
        
        public virtual Patient Patient { get; set; }

    }
}

/*

       [Required]
       public int DoctorId { get; set; }
       [ForeignKey("DoctorId")]

    
        [Required]
        public int PatientId { get; set; }
        [ForeignKey("PatientId")]

    */
