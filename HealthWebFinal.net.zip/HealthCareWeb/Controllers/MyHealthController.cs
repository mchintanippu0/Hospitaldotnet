﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Models;
using WebApplication2.ViewModels;

namespace WebApplication2.Controllers
{
    [Authorize(Roles = "User,Admin")]
    public class MyHealthController : BaseController
    {
        // GET: MyHealth
        public ActionResult Index()
        {
            var userId = User.Identity.GetUserId();

            var UserManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(db));
            ApplicationUser user = UserManager.FindById(userId);
            if (user == null)
            {
                return RedirectToAction("", "Manage", new { area = "" });
            }
            Patient patient = user.Patient;
            if (patient == null) {
                return RedirectToAction("", "Manage", new { area = "" });
            }
            MyHealthViewModel myHealthViewModel = new MyHealthViewModel() {
                ApplicationUser = user,
                Patient = patient,
                //Invoices = patient.Invoices.ToList(),
                PatientMedications = patient.PatientMedications.ToList(),
                PatientTests = patient.PatientTests.ToList(),
                Schedules = patient.Schedules.ToList()
        };

            return View(myHealthViewModel);
        }
    }
}