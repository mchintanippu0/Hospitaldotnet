﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Authorize(Roles = "Admin")]
    public class PatientTestController : BaseController
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: PatientTest
        public ActionResult Index()
        {
            return View(db.PatientTests.ToList());
        }

        // GET: PatientTest/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PatientTest patientTest = db.PatientTests.Find(id);
            if (patientTest == null)
            {
                return HttpNotFound();
            }
            return View(patientTest);
        }

        // GET: PatientTest/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: PatientTest/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "id,TestDate,Result,Price")] PatientTest patientTest)
        {
            if (ModelState.IsValid)
            {
                db.PatientTests.Add(patientTest);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(patientTest);
        }

        // GET: PatientTest/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PatientTest patientTest = db.PatientTests.Find(id);
            if (patientTest == null)
            {
                return HttpNotFound();
            }
            return View(patientTest);
        }

        // POST: PatientTest/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,TestDate,Result,Price")] PatientTest patientTest)
        {
            if (ModelState.IsValid)
            {
                db.Entry(patientTest).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(patientTest);
        }

        // GET: PatientTest/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PatientTest patientTest = db.PatientTests.Find(id);
            if (patientTest == null)
            {
                return HttpNotFound();
            }
            return View(patientTest);
        }

        // POST: PatientTest/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            PatientTest patientTest = db.PatientTests.Find(id);
            db.PatientTests.Remove(patientTest);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
