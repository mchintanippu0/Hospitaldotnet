﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Authorize(Roles = "User,Admin")]
    public class InvoiceController : BaseController
    {

        // GET: Invoice
       // [Authorize(Roles = "Admin")]
        public ActionResult Index()
        {
            List<Invoice> invoices;
            if (User.IsInRole("Admin"))
            {
                invoices = db.Invoices.ToList();
            }
            else
            {
                var userId = User.Identity.GetUserId();
                var UserManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(db));
                ApplicationUser user = UserManager.FindById(userId);
                invoices = (from i in db.Invoices where i.Patient.id == user.Patient.id select i).ToList();
            }
            return View(invoices);
        }

        // GET: Invoice/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                if (User.IsInRole("Admin"))
                    return RedirectToAction("Index");
                return RedirectToAction("", "Manage", new { area = "" });
            }
            Invoice invoice = db.Invoices.Find(id);
            if (invoice == null)
            {
                if (User.IsInRole("Admin"))
                    return RedirectToAction("Index");
                return RedirectToAction("", "Manage", new { area = "" });
            }
            var userId = User.Identity.GetUserId();
            var invoiceUserId = invoice.Patient.User.Id;
            if (userId == invoiceUserId || User.IsInRole("Admin"))
            {
                return View(invoice);
            }
            return RedirectToAction("", "Manage", new { area = "" });
        }

        // GET: Invoice/Create
        [Authorize(Roles = "Admin")]
        public ActionResult Create()
        {
            return View();
        }

        // POST: Invoice/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult Create([Bind(Include = "id,InvoiceDate,Amount,Status")] Invoice invoice)
        {
            if (ModelState.IsValid)
            {
                db.Invoices.Add(invoice);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(invoice);
        }

        // GET: Invoice/Edit/5
        [Authorize(Roles = "Admin")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Invoice invoice = db.Invoices.Find(id);
            if (invoice == null)
            {
                return HttpNotFound();
            }
            return View(invoice);
        }

        // GET: Invoice/Pay/5
        //[Authorize(Roles = "Admin")]
        public ActionResult Pay(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Invoice invoice = db.Invoices.Find(id);
            if (invoice == null)
            {
                return HttpNotFound();
            }

            var userId = User.Identity.GetUserId();
            var invoiceUserId = invoice.Patient.User.Id;
            if (userId == invoiceUserId || User.IsInRole("Admin"))
            {
                invoice.Status = "Paid";
                db.Entry(invoice).State = EntityState.Modified;
                db.SaveChanges();

            }
            return RedirectToAction("Details", new { id = id });

            //return View(invoice);
        }

        // POST: Invoice/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult Edit([Bind(Include = "id,InvoiceDate,Amount,Status")] Invoice invoice)
        {
            if (ModelState.IsValid)
            {
                db.Entry(invoice).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(invoice);
        }

        // GET: Invoice/Delete/5
        [Authorize(Roles = "Admin")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Invoice invoice = db.Invoices.Find(id);
            if (invoice == null)
            {
                return HttpNotFound();
            }
            return View(invoice);
        }

        // POST: Invoice/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Invoice invoice = db.Invoices.Find(id);
            db.Invoices.Remove(invoice);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
