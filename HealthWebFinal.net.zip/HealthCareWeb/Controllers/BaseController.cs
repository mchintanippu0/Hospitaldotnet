﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class BaseController : Controller
    {
        public ApplicationDbContext db = new ApplicationDbContext();
        public Organization organization;

        public UserManager<ApplicationUser> userManager;
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            userManager =  new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(db));

            if (db.Organizations.Count() > 0)
            {
                organization = db.Organizations.ToList().First();
            }
            
            if (organization == null)
            {
                organization = new Organization();
                organization.Name = "Health Care Center";
                organization.Address = "467, ";
                organization.City = "New York";
                organization.Email = "info@healthcare.com";
                organization.Phone = "1264856875";
               // db.Organizations.Add(organization);
               // db.SaveChanges();
            }

            ViewBag.organization = organization;

            ViewBag.someThing = "someThing"; //Add whatever
            base.OnActionExecuting(filterContext);
        }
    }
}