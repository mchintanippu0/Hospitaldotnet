﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Authorize(Roles = "Admin,User")]
    public class ScheduleController : BaseController
    {

        // GET: Schedule
        [Authorize(Roles = "Admin")]
        public ActionResult Index()
        {
            return View(db.Schedules.ToList());
        }

        // GET: Schedule/Details/5
        public ActionResult Details(int? id)
        {

            if (id == null)
            {
                if (User.IsInRole("Admin"))
                    return RedirectToAction("Index");
                return RedirectToAction("", "Manage", new { area = "" });
            }
            Schedule schedule = db.Schedules.Find(id);
            if (schedule == null)
            {
                if (User.IsInRole("Admin"))
                    return RedirectToAction("Index");
                return RedirectToAction("", "Manage", new { area = "" });
            }
            if (User.IsInRole("Admin"))
            {
                return View(schedule);
            }
            Patient patient = userManager.FindById(User.Identity.GetUserId()).Patient;
            if(patient!=null&&patient.id== schedule.Patient.id)
                return View(schedule);
            return RedirectToAction("", "Manage", new { area = "" });           
        }

        // GET: Schedule/Create
        public ActionResult Create()
        {
            ApplicationUser applicationUser = userManager.FindById(User.Identity.GetUserId());
            if (applicationUser == null)
            {
                return RedirectToAction("Login", "Account", new { area = "" });
            }
            fillViewBag();
            return View();
        }

        private void fillViewBag()
        {
            ViewBag.Doctors = db.Doctors.ToList();
            if (User.IsInRole("Admin"))
            {
                ViewBag.Patients = db.Patients.ToList();
            }
            else
            {
                ApplicationUser applicationUser = userManager.FindById(User.Identity.GetUserId());
                if (applicationUser == null)
                {
                     RedirectToAction("Login", "Account", new { area = "" });

                }else {
                    ViewBag.Patient = applicationUser.Patient;
                }
            }

        }
        // POST: Schedule/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "id,ScheduleTime,Doctor,Patient")] Schedule schedule)
        {
            foreach (ModelState modelState in ViewData.ModelState.Values)
            {
                foreach (ModelError error in modelState.Errors)
                {
                    Debug.WriteLine("=======>"+error.ErrorMessage);
                    //DoSomethingWith(error);
                }
            }
            
            if (ModelState.IsValid)
            {
                Debug.WriteLine("Doctor.id is " + schedule.Doctor.id);
                Debug.WriteLine("Patient.id is " + schedule.Patient.id);

                Patient patient = userManager.FindById(User.Identity.GetUserId()).Patient;
                if (User.IsInRole("Admin") || schedule.Patient.id == patient.id)
                {
                    DateTime scheduleTime = schedule.ScheduleTime;

                    //Debug.WriteLine("scheduleTime.DayOfWeek is " + scheduleTime.DayOfWeek);
                    //Debug.WriteLine("scheduleTime.Hour is " + scheduleTime.Hour);
                    //Debug.WriteLine("scheduleTime.Minute is " + scheduleTime.Minute);
                    //Debug.WriteLine("scheduleTime.TimeOfDay is " + scheduleTime.TimeOfDay);
                    if (scheduleTime.DayOfWeek.ToString() == "Sunday")
                    {
                        if (scheduleTime.Hour < 8 || scheduleTime.Hour > 14)
                        {
                            ModelState.AddModelError("", "Please select time within open hours");

                            fillViewBag();
                            return View(schedule);
                        }
                    }
                    else {
                        if (scheduleTime.Hour < 8 || scheduleTime.Hour > 18)
                        {
                            ModelState.AddModelError("", "Please select time within open hours");

                            fillViewBag();
                            return View(schedule);
                        }
                    }
                    // 8-18
                    // sun 8 - 14

                    schedule.Doctor = (from p in db.Doctors where p.id == schedule.Doctor.id select p).FirstOrDefault();
                    schedule.Patient = (from p in db.Patients where p.id == schedule.Patient.id select p).FirstOrDefault();
                    db.Schedules.Add(schedule);
                    db.SaveChanges();
                    if (User.IsInRole("Admin"))
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        return RedirectToAction("", "MyHealth", new { area = "" });
                    }
                }
            }
            fillViewBag();
            return View(schedule);
        }

        // GET: Schedule/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Schedule schedule = db.Schedules.Find(id);
            if (schedule == null)
            {
                return HttpNotFound();
            }
            return View(schedule);
        }

        // POST: Schedule/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,ScheduleTime,Status")] Schedule schedule)
        {
            if (ModelState.IsValid)
            {
                Patient patient = userManager.FindById(User.Identity.GetUserId()).Patient;
                Schedule ss = (from s in db.Schedules where s.id == schedule.id select s).FirstOrDefault();
                
                if (User.IsInRole("Admin") || ss.Patient.id == patient.id)
                {
                    DateTime scheduleTime = schedule.ScheduleTime;
                    if (scheduleTime.DayOfWeek.ToString() == "Sunday")
                    {
                        if (scheduleTime.Hour < 8 || scheduleTime.Hour > 14)
                        {
                            ModelState.AddModelError("", "Please select time within open hours");

                            fillViewBag();
                            return View(schedule);
                        }
                    }
                    else
                    {
                        if (scheduleTime.Hour < 8 || scheduleTime.Hour > 18)
                        {
                            ModelState.AddModelError("", "Please select time within open hours");

                            fillViewBag();
                            return View(schedule);
                        }
                    }
                    db.Schedules.AddOrUpdate(schedule);
                    db.SaveChanges();

                    if (User.IsInRole("Admin"))
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        return RedirectToAction("", "MyHealth", new { area = "" });
                    }
                }
            }
            return View(schedule);
        }

        // GET: Schedule/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Schedule schedule = db.Schedules.Find(id);
            if (schedule == null)
            {
                return HttpNotFound();
            }
            return View(schedule);
        }

        // POST: Schedule/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Schedule schedule = db.Schedules.Find(id);
            db.Schedules.Remove(schedule);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
