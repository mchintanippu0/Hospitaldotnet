﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication2.Models;

namespace WebApplication2.ViewModels
{
    public class MyHealthViewModel
    {
        public ApplicationUser ApplicationUser { get; set; }
        public Patient Patient { get; set; }
        public IList<PatientMedication> PatientMedications { get; set; }
        public IList<PatientTest> PatientTests { get; set; }
        public IList<Invoice> Invoices { get; set; }
        public IList<Schedule> Schedules { get; set; }
    }
}